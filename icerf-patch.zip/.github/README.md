# i Cerf

تطبيق توقيع وتثبيت التطبيقات على الجهاز، مبني على [Feather](https://github.com/khcrysalis/Feather) (GPL-3.0).

- Instagram: eng_azawy
- Telegram: bavarite
- TikTok: eyesiq
- الموقع: https://icerf.netlify.app

الترخيص: GPL-3.0 (راجع ملف LICENSE).
